<?php

namespace App\Filament\Resources\CrewAssignmentResource\Pages;

use App\Filament\Resources\CrewAssignmentResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCrewAssignment extends CreateRecord
{
    protected static string $resource = CrewAssignmentResource::class;
}
