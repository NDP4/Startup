<?php

namespace App\Forms\Components;

use Filament\Forms\Components\Field;

class BusGrid extends Field
{
    protected string $view = 'filament.resources.booking.bus-grid';
}
