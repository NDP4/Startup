<?php

namespace App\Forms\Components;

use Filament\Forms\Components\Field;

class BusCard extends Field
{
    protected string $view = 'filament.forms.components.bus-card';
}
