<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/vendor/filament/forms/src/../resources/views/components/group.blade.php ENDPATH**/ ?>