<p
    <?php echo e($attributes->class(['fi-section-header-description overflow-hidden break-words text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/vendor/filament/support/src/../resources/views/components/section/description.blade.php ENDPATH**/ ?>