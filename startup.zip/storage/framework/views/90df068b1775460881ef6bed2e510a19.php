<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <h2 class="text-lg font-medium text-gray-900">My Bookings</h2>

                    <div class="mt-6">
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-6 mb-4 bg-white border rounded-lg shadow-sm">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-gray-500">Booking #<?php echo e($booking->id); ?></p>
                                        <h3 class="mt-1 text-lg font-semibold"><?php echo e($booking->pickup_location); ?> → <?php echo e($booking->destination); ?></h3>
                                        <div class="mt-2 space-y-1">
                                            <p class="text-sm text-gray-600"><?php echo e($booking->booking_date->format('d M Y H:i')); ?></p>
                                            <p class="text-sm text-gray-600"><?php echo e($booking->bus->name); ?> (<?php echo e($booking->bus->number_plate); ?>)</p>
                                            <p class="font-medium text-gray-900">Rp <?php echo e(number_format($booking->total_amount)); ?></p>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                            'px-3 py-1 text-xs font-medium rounded-full',
                                            'bg-green-100 text-green-800' => $booking->status === 'completed',
                                            'bg-yellow-100 text-yellow-800' => $booking->status === 'pending',
                                            'bg-blue-100 text-blue-800' => $booking->status === 'confirmed',
                                            'bg-red-100 text-red-800' => $booking->status === 'cancelled',
                                        ]); ?>">
                                            <?php echo e(ucfirst($booking->status)); ?>

                                        </span>

                                        <div class="mt-4">
                                            <a href="<?php echo e(route('customer.bookings.show', $booking)); ?>"
                                               class="text-sm font-medium text-primary-600 hover:text-primary-700">
                                                View Details →
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="p-12 text-center">
                                <p class="text-gray-500">You don't have any bookings yet.</p>
                                <a href="<?php echo e(route('buses.index')); ?>" class="inline-block mt-4 btn-primary">
                                    Browse Available Buses
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="mt-6">
                            <?php echo e($bookings->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/customer/bookings/index.blade.php ENDPATH**/ ?>