<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-10">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <div class="grid grid-cols-1 gap-8 md:grid-cols-2">
                        
                        <div class="space-y-4">
                            <div class="aspect-w-16 aspect-h-9">
                                <img id="mainImage"
                                     src="<?php echo e($bus->main_image ? Storage::url($bus->main_image) : asset('images/bus-placeholder.jpg')); ?>"
                                     alt="<?php echo e($bus->name); ?>"
                                     class="object-cover w-full h-full rounded-lg">
                            </div>
                            <?php if(count($bus->all_images) > 0): ?>
                                <div class="grid grid-cols-4 gap-2">
                                    <?php $__currentLoopData = $bus->all_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <button onclick="document.getElementById('mainImage').src = '<?php echo e(Storage::url($image['url'])); ?>'"
                                                class="relative aspect-square group">
                                            <img src="<?php echo e(Storage::url($image['url'])); ?>"
                                                 alt="<?php echo e($image['description'] ?? $bus->name . ' image ' . ($index + 1)); ?>"
                                                 class="object-cover w-full h-full transition duration-300 rounded-lg hover:opacity-75">
                                            <?php if($image['description']): ?>
                                                <div class="absolute inset-0 flex items-end justify-center p-2 transition duration-300 bg-black/0 group-hover:bg-black/40">
                                                    <p class="text-xs text-white opacity-0 group-hover:opacity-100">
                                                        <?php echo e($image['description']); ?>

                                                    </p>
                                                </div>
                                            <?php endif; ?>
                                        </button>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        
                        <div class="space-y-6">
                            <div>
                                <h1 class="text-2xl font-bold"><?php echo e($bus->name); ?></h1>
                                <p class="text-gray-600"><?php echo e($bus->number_plate); ?></p>
                            </div>

                            
                            <div class="flex items-center">
                                <div class="flex text-yellow-400">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <svg class="w-5 h-5 <?php echo e($i <= ceil($averageRating) ? 'text-yellow-400' : 'text-gray-300'); ?>"
                                             fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                        </svg>
                                    <?php endfor; ?>
                                </div>
                                <p class="ml-2 text-sm text-gray-600">
                                    <?php echo e(number_format($averageRating, 1)); ?> (<?php echo e($totalReviews); ?> ulasan)
                                </p>
                            </div>

                            
                            <div class="text-2xl font-bold text-primary-600">
                                <?php if($bus->pricing_type === 'daily'): ?>
                                    Rp <?php echo e(number_format($bus->price_per_day)); ?>/hari
                                <?php else: ?>
                                    Rp <?php echo e(number_format($bus->price_per_km)); ?>/km
                                <?php endif; ?>
                            </div>

                            
                            <div class="grid grid-cols-2 gap-4">
                                <div class="flex items-center">
                                    <svg class="w-5 h-5 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                                    </svg>
                                    <?php echo e($bus->default_seat_capacity); ?> Kursi
                                </div>
                                
                            </div>

                            
                            <div>
                                <h3 class="mb-2 font-semibold">Deskripsi</h3>
                                <p class="text-gray-600"><?php echo e($bus->description); ?></p>
                            </div>

                            
                            <div class="pt-6">
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('booking.create', $bus)); ?>"
                                       class="w-full text-center btn-primary">
                                        Booking Sekarang
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>"
                                       class="w-full text-center btn-secondary">
                                        Login untuk Booking
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="mt-8 overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <h2 class="mb-4 text-xl font-semibold">Ulasan Pelanggan</h2>
                    <?php $__currentLoopData = $bus->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="py-4 border-b border-gray-200 last:border-0">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="font-medium"><?php echo e($review->customer->name); ?></p>
                                    <div class="flex mt-1 text-yellow-400">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <svg class="w-4 h-4 <?php echo e($i <= $review->bus_rating ? 'text-yellow-400' : 'text-gray-300'); ?>"
                                                 fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                            </svg>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <span class="text-sm text-gray-500">
                                    <?php echo e($review->created_at->format('d M Y')); ?>

                                </span>
                            </div>
                            <p class="mt-2 text-gray-600"><?php echo e($review->bus_comment); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function changeMainImage(url) {
            document.getElementById('mainImage').src = url;
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /app/resources/views/buses/show.blade.php ENDPATH**/ ?>