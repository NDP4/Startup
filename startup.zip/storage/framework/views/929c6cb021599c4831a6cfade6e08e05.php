<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <h2 class="text-lg font-medium text-gray-900">Assigned Crew</h2>

                    <div class="mt-6">
                        <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-6 mb-4 bg-white border rounded-lg shadow-sm">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center justify-center w-12 h-12 rounded-full bg-primary-100">
                                                <span class="text-lg font-medium text-primary-600">
                                                    <?php echo e(strtoupper(substr($assignment->crew->name, 0, 2))); ?>

                                                </span>
                                            </div>
                                            <div>
                                                <h3 class="font-medium text-gray-900"><?php echo e($assignment->crew->name); ?></h3>
                                                <p class="text-sm text-gray-500"><?php echo e($assignment->role); ?></p>
                                            </div>
                                        </div>

                                        <div class="mt-4 space-y-1 text-sm">
                                            <p class="text-gray-600">
                                                <span class="font-medium">Booking:</span>
                                                #<?php echo e($assignment->booking->id); ?>

                                            </p>
                                            <p class="text-gray-600">
                                                <span class="font-medium">Trip:</span>
                                                <?php echo e($assignment->booking->pickup_location); ?> → <?php echo e($assignment->booking->destination); ?>

                                            </p>
                                            <p class="text-gray-600">
                                                <span class="font-medium">Date:</span>
                                                <?php echo e($assignment->booking->booking_date->format('d M Y H:i')); ?>

                                            </p>
                                        </div>
                                    </div>

                                    <div class="text-right">
                                        <a href="<?php echo e(route('customer.crew-assignments.show', $assignment)); ?>"
                                           class="text-sm font-medium text-primary-600 hover:text-primary-700">
                                            View Details →
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="p-12 text-center">
                                <p class="text-gray-500">No crew assignments found.</p>
                            </div>
                        <?php endif; ?>

                        <div class="mt-6">
                            <?php echo e($assignments->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/customer/crew-assignments/index.blade.php ENDPATH**/ ?>