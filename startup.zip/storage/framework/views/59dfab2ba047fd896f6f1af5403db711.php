<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <h2 class="text-lg font-medium text-gray-900">My Reviews</h2>

                    <div class="mt-6">
                        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-6 mb-4 bg-white border rounded-lg shadow-sm">
                                <div class="flex items-start justify-between">
                                    <div>
                                        <div class="flex items-center gap-2">
                                            <h3 class="font-medium"><?php echo e($review->booking->bus->name); ?></h3>
                                            <span class="text-sm text-gray-500">
                                                <?php echo e($review->created_at->format('d M Y')); ?>

                                            </span>
                                        </div>

                                        
                                        <div class="flex mt-2 text-yellow-400">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <svg class="w-5 h-5 <?php echo e($i <= $review->bus_rating ? 'text-yellow-400' : 'text-gray-300'); ?>"
                                                     fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                                </svg>
                                            <?php endfor; ?>
                                        </div>

                                        
                                        <p class="mt-2 text-gray-600"><?php echo e($review->bus_comment); ?></p>

                                        
                                        <div class="mt-4 text-sm text-gray-500">
                                            <?php echo e($review->booking->pickup_location); ?> → <?php echo e($review->booking->destination); ?>

                                            <span class="mx-2">•</span>
                                            <?php echo e($review->booking->booking_date->format('d M Y')); ?>

                                        </div>
                                    </div>

                                    
                                    <div>
                                        <a href="<?php echo e(route('customer.bookings.show', $review->booking)); ?>"
                                           class="text-sm font-medium text-primary-600 hover:text-primary-700">
                                            View Booking →
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="p-12 text-center">
                                <p class="text-gray-500">You haven't written any reviews yet.</p>
                                <a href="<?php echo e(route('customer.bookings.index')); ?>" class="inline-block mt-4 btn-primary">
                                    View Your Bookings
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="mt-6">
                            <?php echo e($reviews->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/customer/reviews/index.blade.php ENDPATH**/ ?>