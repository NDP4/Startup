<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kwitansi #<?php echo e($booking->id); ?> - <?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        * {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen p-6">
        <div class="max-w-4xl mx-auto">
            
            <div class="flex items-center justify-between mb-6">
                <h1 class="text-2xl font-bold text-gray-900">Kwitansi Pembayaran</h1>
                <div class="space-x-2">
                    <div class="flex justify-end gap-4 mt-6">
                        <?php if(auth()->user()->role === 'customer'): ?>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn-secondary">
                                Back
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('filament.panel.resources.bookings.index')); ?>" class="btn-secondary">
                                Back to Bookings
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('booking.receipt.download', $booking)); ?>" class="btn-primary">
                            <svg class="inline-block w-5 h-5 mr-2 -ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                            </svg>
                            Download Receipt
                        </a>
                    </div>
                </div>
            </div>

            
            <div class="p-8 bg-white shadow-lg rounded-2xl">
                
                <div class="flex items-start justify-between mb-12">
                    <div>
                        <h2 class="mb-1 text-3xl font-bold text-gray-900"><?php echo e(config('app.name')); ?></h2>
                        <div class="space-y-1 text-gray-600">
                            <p>Jl. Contoh No. 123, Semarang Selatan</p>
                            <p>Indonesia 12345</p>
                            <p>Tel: (021) 123-4567</p>
                            <p>Email: info@bookingbus.com</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="px-4 py-2 mb-4 text-sm font-medium text-white bg-blue-600 rounded-lg">KWITANSI</div>
                        <p class="mb-1 text-2xl font-bold text-gray-900">#<?php echo e(str_pad($booking->id, 5, '0', STR_PAD_LEFT)); ?></p>
                        <p class="text-gray-600"><?php echo e($booking->created_at->format('d F Y')); ?></p>
                    </div>
                </div>

                
                <div class="p-6 mb-8 border border-gray-100 rounded-xl bg-gray-50">
                    <h3 class="mb-4 text-sm font-medium text-gray-500">CUSTOMER</h3>
                    <p class="mb-2 text-xl font-bold text-gray-900"><?php echo e($booking->customer->name); ?></p>
                    <div class="space-y-1 text-gray-600">
                        <p><?php echo e($booking->customer->address ?: '-'); ?></p>
                        <p>Tel: <?php echo e($booking->customer->phone ?: '-'); ?></p>
                        <p>Email: <?php echo e($booking->customer->email); ?></p>
                    </div>
                </div>

                
                <div class="mb-8">
                    <table class="w-full">
                        <thead>
                            <tr>
                                <th class="px-4 py-3 text-sm font-medium tracking-wider text-left text-gray-500 uppercase bg-gray-50">Deskripsi</th>
                                <th class="px-4 py-3 text-sm font-medium tracking-wider text-right text-gray-500 uppercase bg-gray-50">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <tr>
                                <td class="px-4 py-4">
                                    <p class="text-lg font-semibold text-gray-900">Sewa Bus <?php echo e($booking->bus->name); ?></p>
                                    <div class="mt-4 space-y-2">
                                        <?php
                                            if ($booking->bus->pricing_type === 'daily') {
                                                $days = $booking->return_date
                                                    ? ceil($booking->booking_date->floatDiffInDays($booking->return_date))
                                                    : 1;
                                            }
                                        ?>

                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <p class="text-sm text-gray-500">Lokasi Penjemputan</p>
                                                <p class="text-gray-900"><?php echo e($booking->pickup_location); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-gray-500">Tujuan</p>
                                                <p class="text-gray-900"><?php echo e($booking->destination); ?></p>
                                            </div>
                                        </div>

                                        <div>
                                            <p class="text-sm text-gray-500">Waktu</p>
                                            <p class="text-gray-900">
                                                <?php echo e($booking->booking_date->format('d M Y H:i')); ?>

                                                <?php if($booking->return_date): ?>
                                                    - <?php echo e($booking->return_date->format('d M Y H:i')); ?>

                                                <?php endif; ?>
                                            </p>
                                        </div>

                                        <?php if($booking->special_requests): ?>
                                            <div>
                                                <p class="text-sm text-gray-500">Catatan</p>
                                                <p class="text-gray-900"><?php echo e($booking->special_requests); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($booking->bus->pricing_type === 'daily'): ?>
                                            <p class="mt-2 text-gray-600">
                                                <?php echo e($days); ?> hari × Rp <?php echo e(number_format($booking->bus->price_per_day, 0, ',', '.')); ?>/hari
                                            </p>
                                        <?php else: ?>
                                            <p class="mt-2 text-gray-600">
                                                Estimasi 100 km × Rp <?php echo e(number_format($booking->bus->price_per_km, 0, ',', '.')); ?>/km
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-4 py-4 text-right">
                                    <span class="text-lg font-semibold text-gray-900">
                                        <?php if($booking->bus->pricing_type === 'daily'): ?>
                                            Rp <?php echo e(number_format($booking->bus->price_per_day * $days, 0, ',', '.')); ?>

                                        <?php else: ?>
                                            Rp <?php echo e(number_format($booking->bus->price_per_km * 100, 0, ',', '.')); ?>

                                        <?php endif; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php if($booking->seat_type === 'legrest'): ?>
                            <tr>
                                <td class="px-4 py-4">
                                    <p class="text-gray-600">
                                        Tambahan Kursi Legrest (<?php echo e($booking->total_seats); ?> kursi × Rp <?php echo e(number_format($booking->bus->legrest_price_per_seat, 0, ',', '.')); ?>)
                                    </p>
                                </td>
                                <td class="px-4 py-4 text-right">
                                    <span class="text-lg font-semibold text-gray-900">
                                        Rp <?php echo e(number_format($booking->bus->legrest_price_per_seat * $booking->total_seats, 0, ',', '.')); ?>

                                    </span>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="border-t-2 border-gray-900">
                                <td class="px-4 py-4 text-right">
                                    <span class="text-sm font-medium text-gray-600">Total</span>
                                </td>
                                <td class="px-4 py-4 text-right">
                                    <span class="text-2xl font-bold text-gray-900">
                                        Rp <?php echo e(number_format($booking->total_amount, 0, ',', '.')); ?>

                                    </span>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                
                <div class="p-4 mb-8 text-sm border border-blue-200 rounded-lg bg-blue-50">
                    <span class="font-medium text-blue-800">
                        Terbilang: <?php echo e(ucwords(\App\Helpers\Terbilang::make($booking->total_amount))); ?> Rupiah
                    </span>
                </div>

                <!-- Payment Info -->
                <div class="p-6 mb-8 border border-gray-200 rounded-lg bg-gray-50">
                    <h4 class="mb-4 text-lg font-semibold text-gray-900">Informasi Pembayaran</h4>
                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <?php
                            $payment = $booking->payments->last();
                            $details = $payment?->payment_details ?? [];

                            // Get dates safely
                            $transactionTime = !empty($details['transaction_time'])
                                ? \Carbon\Carbon::parse($details['transaction_time'])->format('d M Y, H:i')
                                : (!empty($booking->created_at)
                                    ? $booking->created_at->format('d M Y, H:i')
                                    : '-');

                            $settlementTime = !empty($details['settlement_time'])
                                ? \Carbon\Carbon::parse($details['settlement_time'])->format('d M Y, H:i')
                                : (!empty($payment?->paid_at)
                                    ? $payment->paid_at->format('d M Y, H:i')
                                    : '-');

                            // Get VA number safely
                            $vaNumber = null;
                            if (!empty($details['va_numbers']) && is_array($details['va_numbers'])) {
                                $vaNumber = $details['va_numbers'][0]['va_number'] ?? null;
                            }
                            $vaNumber = $vaNumber ?? $details['va_number'] ?? '-';

                            // Get bank safely
                            $bank = null;
                            if (!empty($details['va_numbers']) && is_array($details['va_numbers'])) {
                                $bank = strtoupper($details['va_numbers'][0]['bank'] ?? '');
                            }
                            $bank = $bank ?? $details['bank'] ?? '-';
                        ?>

                        <div>
                            <p class="text-gray-600">Status Pembayaran</p>
                            <p class="font-medium text-gray-900"><?php echo e(ucfirst($booking->payment_status)); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600">Metode Pembayaran</p>
                            <p class="font-medium text-gray-900"><?php echo e($details['payment_type'] ?? '-'); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-gray-600">Waktu Transaksi</p>
                            <p class="font-medium text-gray-900"><?php echo e($transactionTime); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600">Waktu Pembayaran</p>
                            <p class="font-medium text-gray-900"><?php echo e($settlementTime); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600">ID Transaksi</p>
                            <p class="font-medium text-gray-900"><?php echo e($details['transaction_id'] ?? '-'); ?></p>
                        </div>
                        
                    </div>
                </div>

                
                <div class="flex justify-end pt-8 mt-12 border-t">
                    <div class="text-center">
                        <p class="mb-16 text-gray-600">Hormat Kami,</p>
                        <p class="font-semibold text-gray-900"><?php echo e(config('app.name')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/receipts/show.blade.php ENDPATH**/ ?>