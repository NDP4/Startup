<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <form action="<?php echo e(route('booking.store', $bus)); ?>" method="POST" class="p-6">
                    <?php echo csrf_field(); ?>

                    <?php if(session('error')): ?>
                        <div class="p-4 mb-6 text-red-700 bg-red-100 rounded-lg">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php if($errors->any()): ?>
                        <div class="p-4 mb-6 text-red-700 bg-red-100 rounded-lg">
                            <ul class="list-disc list-inside">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="space-y-8">
                        
                        <div>
                            <h2 class="text-lg font-medium text-gray-900">Bus Information</h2>
                            <div class="flex items-center gap-4 mt-4">
                                <?php if($bus->images && count($bus->images) > 0): ?>
                                    <img src="<?php echo e(Storage::url($bus->images[0])); ?>"
                                         alt="<?php echo e($bus->name); ?>"
                                         class="object-cover w-24 h-24 rounded-lg">
                                <?php endif; ?>
                                <div>
                                    <h3 class="font-medium"><?php echo e($bus->name); ?></h3>
                                    <p class="text-sm text-gray-600"><?php echo e($bus->number_plate); ?></p>
                                    <p class="mt-1 text-sm text-primary-600">
                                        <?php if($bus->pricing_type === 'daily'): ?>
                                            Rp <?php echo e(number_format($bus->price_per_day)); ?>/day
                                        <?php else: ?>
                                            Rp <?php echo e(number_format($bus->price_per_km)); ?>/km
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                        
                        <div>
                            <h2 class="text-lg font-medium text-gray-900">Trip Details</h2>
                            <div class="grid grid-cols-1 gap-6 mt-4 sm:grid-cols-2">
                                <div>
                                    <label for="booking_date" class="block text-sm font-medium text-gray-700">Departure Date</label>
                                    <input type="datetime-local" name="booking_date" id="booking_date"
                                           class="mt-1 form-input" required>
                                </div>

                                <div>
                                    <label for="return_date" class="block text-sm font-medium text-gray-700">Return Date</label>
                                    <input type="datetime-local" name="return_date" id="return_date"
                                           class="mt-1 form-input" required>
                                </div>

                                <div class="sm:col-span-2">
                                    <label for="pickup_location" class="block text-sm font-medium text-gray-700">Pickup Location</label>
                                    <input type="text" name="pickup_location" id="pickup_location"
                                           class="mt-1 form-input" required>
                                </div>

                                <div class="sm:col-span-2">
                                    <label for="destination" class="block text-sm font-medium text-gray-700">Destination</label>
                                    <input type="text" name="destination" id="destination"
                                           class="mt-1 form-input" required>
                                </div>
                            </div>
                        </div>

                        
                        <div>
                            <h2 class="text-lg font-medium text-gray-900">Seat Selection</h2>
                            <div class="grid grid-cols-1 gap-6 mt-4 sm:grid-cols-2">
                                <div>
                                    <label for="total_seats" class="block text-sm font-medium text-gray-700">Number of Seats</label>
                                    <input type="number" name="total_seats" id="total_seats"
                                           class="mt-1 form-input" min="1" max="<?php echo e($bus->default_seat_capacity); ?>" required>
                                </div>

                                <div>
                                    <label for="seat_type" class="block text-sm font-medium text-gray-700">Seat Type</label>
                                    <select name="seat_type" id="seat_type" class="mt-1 form-input" required>
                                        <option value="standard">Standard</option>
                                        <option value="legrest">Legrest (+<?php echo e(number_format($bus->legrest_price_per_seat)); ?>)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        
                        <div>
                            <h2 class="text-lg font-medium text-gray-900">Additional Requests</h2>
                            <div class="mt-4">
                                <textarea name="special_requests" id="special_requests" rows="4"
                                          class="form-input" placeholder="Any special requests?"></textarea>
                            </div>
                        </div>

                        
                        <div class="flex justify-end gap-4">
                            <a href="<?php echo e(route('buses.index')); ?>" class="btn-secondary">Cancel</a>
                            <button type="submit" class="btn-primary">
                                Continue to Payment
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/booking/create.blade.php ENDPATH**/ ?>