<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-medium text-gray-900">Crew Assignment Details</h2>
                        <a href="<?php echo e(route('customer.crew-assignments.index')); ?>"
                           class="text-sm font-medium text-primary-600 hover:text-primary-700">
                            ← Back to List
                        </a>
                    </div>

                    
                    <div class="p-6 mb-6 rounded-lg bg-gray-50">
                        <div class="flex items-center gap-4">
                            <div class="flex items-center justify-center w-16 h-16 rounded-full bg-primary-100">
                                <span class="text-2xl font-medium text-primary-600">
                                    <?php echo e(strtoupper(substr($assignment->crew->name, 0, 2))); ?>

                                </span>
                            </div>
                            <div>
                                <h3 class="text-xl font-medium text-gray-900"><?php echo e($assignment->crew->name); ?></h3>
                                <p class="text-gray-500"><?php echo e($assignment->role); ?></p>
                                <?php if($assignment->crew->phone): ?>
                                    <p class="mt-2 text-sm text-gray-600">
                                        <span class="font-medium">Contact:</span> <?php echo e($assignment->crew->phone); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="grid gap-6 md:grid-cols-2">
                        <div>
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Trip Details</h4>
                            <div class="p-4 space-y-2 rounded-lg bg-gray-50">
                                <p><span class="font-medium">Booking ID:</span> #<?php echo e($assignment->booking->id); ?></p>
                                <p><span class="font-medium">From:</span> <?php echo e($assignment->booking->pickup_location); ?></p>
                                <p><span class="font-medium">To:</span> <?php echo e($assignment->booking->destination); ?></p>
                                <p><span class="font-medium">Date:</span> <?php echo e($assignment->booking->booking_date->format('d M Y H:i')); ?></p>
                                <?php if($assignment->booking->return_date): ?>
                                    <p><span class="font-medium">Return:</span> <?php echo e($assignment->booking->return_date->format('d M Y H:i')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div>
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Bus Information</h4>
                            <div class="p-4 space-y-2 rounded-lg bg-gray-50">
                                <p><span class="font-medium">Bus:</span> <?php echo e($assignment->booking->bus->name); ?></p>
                                <p><span class="font-medium">Plate Number:</span> <?php echo e($assignment->booking->bus->number_plate); ?></p>
                                <p><span class="font-medium">Seats:</span> <?php echo e($assignment->booking->total_seats); ?> (<?php echo e(ucfirst($assignment->booking->seat_type)); ?>)</p>
                            </div>
                        </div>
                    </div>

                    
                    <?php if($assignment->notes): ?>
                        <div class="mt-6">
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Notes & Instructions</h4>
                            <div class="p-4 rounded-lg bg-gray-50">
                                <p class="text-gray-600"><?php echo e($assignment->notes); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /app/resources/views/customer/crew-assignments/show.blade.php ENDPATH**/ ?>