<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kwitansi #<?php echo e($booking->id); ?></title>
    <style>
        @page {
            margin: 40px;
        }
        body {
            font-family: 'Helvetica', sans-serif;
            margin: 0;
            padding: 0;
            color: #111827;
        }
        .container {
            padding: 20px;  /* Kurangi dari 40px */
            position: relative;
        }
        .header {
            margin-bottom: 30px;  /* Kurangi dari 60px */
        }
        .company-info {
            float: left;
        }
        .company-info h1 {
            font-size: 24px;
            margin: 0 0 10px 0;
        }
        .company-info p {
            color: #4B5563;
            margin: 5px 0;
            font-size: 14px;
        }
        .receipt-info {
            float: right;
            text-align: right;
        }
        .receipt-badge {
            display: inline-block;
            background: #2563eb;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 14px;
            margin-bottom: 16px;
        }
        .receipt-number {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }
        .receipt-date {
            color: #4B5563;
            margin: 5px 0;
        }
        .clear {
            clear: both;
        }
        .customer-info {
            background: #F9FAFB;
            border: 1px solid #F3F4F6;
            border-radius: 12px;
            padding: 16px;  /* Kurangi dari 24px */
            margin-bottom: 20px;  /* Kurangi dari 40px */
        }
        .customer-info h3 {
            color: #6B7280;
            font-size: 12px;
            text-transform: uppercase;
            margin: 0 0 16px 0;
        }
        .customer-name {
            font-size: 20px;
            font-weight: bold;
            margin: 0 0 12px 0;
        }
        .customer-details {
            color: #4B5563;
            font-size: 14px;
            margin: 5px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th {
            background: #F9FAFB;
            padding: 12px 16px;
            text-align: left;
            font-size: 12px;
            text-transform: uppercase;
            color: #6B7280;
        }
        td {
            padding: 8px 16px;  /* Kurangi padding vertical */
            border-bottom: 1px solid #F3F4F6;
        }
        .item-name {
            font-size: 16px;
            font-weight: bold;
        }
        .item-details {
            color: #4B5563;
            font-size: 14px;
            margin: 2px 0;  /* Kurangi dari 5px */
        }
        .total-row td {
            border-top: 2px solid #111827;
            font-size: 20px;
            font-weight: bold;
            padding-top: 20px;
        }
        .amount-in-words {
            background: #EFF6FF;
            border: 1px solid #BFDBFE;
            border-radius: 8px;
            padding: 16px;
            color: #1E40AF;
            font-size: 14px;
            margin: 30px 0;
        }
        .signature {
            text-align: right;
            margin-top: 60px;
            padding-top: 30px;
            border-top: 1px solid #E5E7EB;
        }
        .signature p {
            margin: 5px 0;
        }
        .signature .sign-line {
            margin: 50px 0 10px 0;
            border-top: 1px solid #111827;
            width: 200px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="company-info">
                <h1><?php echo e(config('app.name')); ?></h1>
                <p>Jl. Contoh No. 123, Semarang Selatan</p>
                <p>Indonesia 12345</p>
                <p>Tel: (021) 123-4567</p>
                <p>Email: info@bookingbus.com</p>
            </div>
            <div class="receipt-info">
                <div class="receipt-badge">KWITANSI</div>
                <p class="receipt-number">#<?php echo e(str_pad($booking->id, 5, '0', STR_PAD_LEFT)); ?></p>
                <p class="receipt-date"><?php echo e($booking->created_at->format('d/m/Y')); ?></p>
            </div>
            <div class="clear"></div>
        </div>

        <div class="customer-info">
            <h3>Telah diterima dari:</h3>
            <p class="customer-name"><?php echo e($booking->customer->name); ?></p>
            <p class="customer-details"><?php echo e($booking->customer->address ?: '-'); ?></p>
            <p class="customer-details">Tel: <?php echo e($booking->customer->phone ?: '-'); ?></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Deskripsi</th>
                    <th style="text-align: right">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <p class="item-name">Sewa Bus <?php echo e($booking->bus->name); ?></p>
                        <?php
                            if ($booking->bus->pricing_type === 'daily') {
                                $days = $booking->return_date
                                    ? ceil($booking->booking_date->floatDiffInDays($booking->return_date))
                                    : 1;
                            }
                        ?>

                        <div style="margin-top: 8px;">  <!-- Kurangi dari 16px -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 4px;">  <!-- Kurangi gap dan margin -->
                                <div>
                                    <p style="font-size: 12px; color: #6B7280; margin-bottom: 2px;">Lokasi Penjemputan</p>
                                    <p style="margin-top: 2px; color: #111827;"><?php echo e($booking->pickup_location); ?></p>
                                </div>
                                <div>
                                    <p style="font-size: 12px; color: #6B7280; margin-bottom: 2px;">Tujuan</p>
                                    <p style="margin-top: 2px; color: #111827;"><?php echo e($booking->destination); ?></p>
                                </div>
                            </div>

                            <div style="margin-bottom: 4px;">  <!-- Kurangi dari 16px -->
                                <p style="font-size: 12px; color: #6B7280; margin-bottom: 2px;">Waktu</p>
                                <p style="margin-top: 2px; color: #111827;">
                                    <?php echo e($booking->booking_date->format('d M Y H:i')); ?>

                                    <?php if($booking->return_date): ?>
                                        - <?php echo e($booking->return_date->format('d M Y H:i')); ?>

                                    <?php endif; ?>
                                </p>
                            </div>

                            <?php if($booking->special_requests): ?>
                                <div style="margin-bottom: 4px;">  <!-- Kurangi dari 16px -->
                                    <p style="font-size: 12px; color: #6B7280; margin-bottom: 2px;">Catatan</p>
                                    <p style="margin-top: 2px; color: #111827;"><?php echo e($booking->special_requests); ?></p>
                                </div>
                            <?php endif; ?>

                            <div style="margin-top: 4px;">
                                <?php if($booking->bus->pricing_type === 'daily'): ?>
                                    <p style="color: #4B5563;">
                                        <?php echo e($days); ?> hari × Rp <?php echo e(number_format($booking->bus->price_per_day, 0, ',', '.')); ?>/hari
                                    </p>
                                <?php else: ?>
                                    <p style="color: #4B5563;">
                                        Estimasi 100 km × Rp <?php echo e(number_format($booking->bus->price_per_km, 0, ',', '.')); ?>/km
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td style="text-align: right">
                        <?php if($booking->bus->pricing_type === 'daily'): ?>
                            Rp <?php echo e(number_format($booking->bus->price_per_day * $days, 0, ',', '.')); ?>

                        <?php else: ?>
                            Rp <?php echo e(number_format($booking->bus->price_per_km * 100, 0, ',', '.')); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($booking->seat_type === 'legrest'): ?>
                <tr>
                    <td>
                        <p class="item-details">Tambahan Kursi Legrest (<?php echo e($booking->total_seats); ?> kursi × Rp <?php echo e(number_format($booking->bus->legrest_price_per_seat, 0, ',', '.')); ?>)</p>
                    </td>
                    <td style="text-align: right">
                        Rp <?php echo e(number_format($booking->bus->legrest_price_per_seat * $booking->total_seats, 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <td style="text-align: right">Total</td>
                    <td style="text-align: right">
                        Rp <?php echo e(number_format($booking->total_amount, 0, ',', '.')); ?>

                    </td>
                </tr>
            </tfoot>
        </table>

        <div class="amount-in-words">
            Terbilang: <?php echo e(ucwords(\App\Helpers\Terbilang::make($booking->total_amount))); ?> Rupiah
        </div>

        <!-- Payment Info -->
        <div class="payment-info">
            <h3 style="margin-bottom: 16px; color: #374151; font-size: 16px; font-weight: 600;">Informasi Pembayaran</h3>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <?php
                    $payment = $booking->payments->last();
                    $details = $payment?->payment_details ?? [];

                    // Get dates safely
                    $transactionTime = !empty($details['transaction_time'])
                        ? \Carbon\Carbon::parse($details['transaction_time'])->format('d M Y, H:i')
                        : (!empty($booking->created_at)
                            ? $booking->created_at->format('d M Y, H:i')
                            : '-');

                    $settlementTime = !empty($details['settlement_time'])
                        ? \Carbon\Carbon::parse($details['settlement_time'])->format('d M Y, H:i')
                        : (!empty($payment?->paid_at)
                            ? $payment->paid_at->format('d M Y, H:i')
                            : '-');

                    // Get VA number safely
                    $vaNumber = null;
                    if (!empty($details['va_numbers']) && is_array($details['va_numbers'])) {
                        $vaNumber = $details['va_numbers'][0]['va_number'] ?? null;
                    }
                    $vaNumber = $vaNumber ?? $details['va_number'] ?? '-';

                    // Get bank safely
                    $bank = null;
                    if (!empty($details['va_numbers']) && is_array($details['va_numbers'])) {
                        $bank = strtoupper($details['va_numbers'][0]['bank'] ?? '');
                    }
                    $bank = $bank ?? $details['bank'] ?? '-';
                ?>

                <tr>
                    <td style="padding: 8px 0; width: 200px;"><strong>Status Pembayaran:</strong></td>
                    <td><?php echo e(ucfirst($booking->payment_status)); ?></td>
                </tr>
                <tr>
                    <td style="padding: 8px 0;"><strong>Metode Pembayaran:</strong></td>
                    <td><?php echo e($details['payment_type'] ?? '-'); ?></td>
                </tr>
                
                <tr>
                    <td style="padding: 8px 0;"><strong>Waktu Transaksi:</strong></td>
                    <td><?php echo e($transactionTime); ?></td>
                </tr>
                <tr>
                    <td style="padding: 8px 0;"><strong>Waktu Pembayaran:</strong></td>
                    <td><?php echo e($settlementTime); ?></td>
                </tr>
                <tr>
                    <td style="padding: 8px 0;"><strong>ID Transaksi:</strong></td>
                    <td><?php echo e($details['transaction_id'] ?? '-'); ?></td>
                </tr>
                
            </table>
        </div>

        <div class="signature">
            <p>Hormat Kami,</p>
            <div class="sign-line"></div>
            <p><?php echo e(config('app.name')); ?></p>
        </div>
    </div>
</body>
</html>
<?php /**PATH /app/resources/views/receipts/pdf.blade.php ENDPATH**/ ?>