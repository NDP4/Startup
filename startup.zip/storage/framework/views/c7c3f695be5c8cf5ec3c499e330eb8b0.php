<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 mt-5">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm rounded-xl">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-medium text-gray-900">Booking Details</h2>
                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'px-3 py-1 text-sm font-medium rounded-full',
                            'bg-green-100 text-green-800' => $booking->status === 'completed',
                            'bg-yellow-100 text-yellow-800' => $booking->status === 'pending',
                            'bg-blue-100 text-blue-800' => $booking->status === 'confirmed',
                            'bg-red-100 text-red-800' => $booking->status === 'cancelled',
                        ]); ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </div>

                    
                    <div class="p-4 mb-6 rounded-lg bg-gray-50">
                        <div class="flex gap-4">
                            <?php if($booking->bus->images && count($booking->bus->images) > 0): ?>
                                <img src="<?php echo e(Storage::url($booking->bus->images[0])); ?>"
                                     class="object-cover w-24 h-24 rounded-lg">
                            <?php endif; ?>
                            <div>
                                <h3 class="font-medium"><?php echo e($booking->bus->name); ?></h3>
                                <p class="text-sm text-gray-600"><?php echo e($booking->bus->number_plate); ?></p>
                                <p class="mt-2 text-sm"><?php echo e($booking->total_seats); ?> Seats (<?php echo e(ucfirst($booking->seat_type)); ?>)</p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="grid gap-6 mb-6 md:grid-cols-2">
                        <div>
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Trip Details</h4>
                            <div class="space-y-2">
                                <p><span class="text-gray-600">From:</span> <?php echo e($booking->pickup_location); ?></p>
                                <p><span class="text-gray-600">To:</span> <?php echo e($booking->destination); ?></p>
                                <p><span class="text-gray-600">Date:</span> <?php echo e($booking->booking_date->format('d M Y H:i')); ?></p>
                                <?php if($booking->return_date): ?>
                                    <p><span class="text-gray-600">Return:</span> <?php echo e($booking->return_date->format('d M Y H:i')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div>
                            <h4 class="mb-2 text-sm font-medium text-gray-700">Payment Details</h4>
                            <div class="space-y-2">
                                <p><span class="text-gray-600">Total Amount:</span> Rp <?php echo e(number_format($booking->total_amount)); ?></p>
                                <p><span class="text-gray-600">Payment Status:</span>
                                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'px-2 py-0.5 text-xs font-medium rounded-full',
                                        'bg-green-100 text-green-800' => $booking->payment_status === 'paid',
                                        'bg-yellow-100 text-yellow-800' => $booking->payment_status === 'pending',
                                        'bg-red-100 text-red-800' => $booking->payment_status === 'failed',
                                    ]); ?>">
                                        <?php echo e(ucfirst($booking->payment_status)); ?>

                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="flex justify-end gap-4">
                        <a href="<?php echo e(route('customer.bookings.index')); ?>" class="btn-secondary">
                            Back to Bookings
                        </a>
                        <?php if($booking->canRetryPayment()): ?>
                            <a href="<?php echo e(route('payment.checkout', $booking)); ?>" class="btn-primary">
                                Pay Now
                            </a>
                        <?php else: ?>
                            <?php if($booking->payment_status === 'paid'): ?>
                                <a href="<?php echo e(route('booking.receipt', $booking)); ?>" class="btn-primary">
                                    <svg class="inline-block w-5 h-5 mr-2 -ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                    View Receipt
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($booking->status === 'completed' && !$booking->review): ?>
                            <a href="<?php echo e(route('reviews.create', $booking)); ?>" class="btn-primary">
                                Write Review
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/kuliah/Semester 4/startup/project_web/BB_L11/Booking_bus-12/resources/views/customer/bookings/show.blade.php ENDPATH**/ ?>